static int width_statuscolors(Bar *bar, BarArg *a);
static int draw_statuscolors(Bar *bar, BarArg *a);
static int click_statuscolors(Bar *bar, Arg *arg, BarArg *a);
static int textw_wosc(char *s);
static int draw_wosc(Bar *bar, BarArg *a, char *s);
