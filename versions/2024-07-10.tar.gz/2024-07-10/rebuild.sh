#!/bin/bash

make clean
rm patches.h
make
sudo make install
make clean
rm patches.h
rm config.h