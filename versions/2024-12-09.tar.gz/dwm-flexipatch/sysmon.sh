#!/bin/bash

make
sudo make install