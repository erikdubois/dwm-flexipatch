static void bstackhoriz(Monitor *m);

