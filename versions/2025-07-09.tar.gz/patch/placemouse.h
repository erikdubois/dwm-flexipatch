static void moveorplace(const Arg *arg);
static void placemouse(const Arg *arg);
