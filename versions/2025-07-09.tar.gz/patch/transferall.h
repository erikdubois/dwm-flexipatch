static void transferall(const Arg *arg);

