static void winview(const Arg* arg);

