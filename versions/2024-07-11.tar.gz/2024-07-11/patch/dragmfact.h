static void dragmfact(const Arg *arg);

