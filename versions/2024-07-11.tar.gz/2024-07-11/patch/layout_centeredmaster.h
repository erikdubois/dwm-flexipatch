static void centeredmaster(Monitor *m);

