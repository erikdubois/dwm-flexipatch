static int width_ltsymbol(Bar *bar, BarArg *a);
static int draw_ltsymbol(Bar *bar, BarArg *a);
static int click_ltsymbol(Bar *bar, Arg *arg, BarArg *a);

